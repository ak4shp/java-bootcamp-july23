package model;

public class MovieStore {

}
