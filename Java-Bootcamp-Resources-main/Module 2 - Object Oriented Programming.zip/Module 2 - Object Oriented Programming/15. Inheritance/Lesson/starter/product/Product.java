package product;

public class Product {
    

}
