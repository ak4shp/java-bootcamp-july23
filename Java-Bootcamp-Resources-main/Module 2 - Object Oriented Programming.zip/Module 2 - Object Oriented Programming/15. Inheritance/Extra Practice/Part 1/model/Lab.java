package model;

public class Lab {
    
}
