package constants;

public enum TradeAccountType {
    CASH, MARGIN;
}