package repository;


public class TradeAccountRepository {


}
