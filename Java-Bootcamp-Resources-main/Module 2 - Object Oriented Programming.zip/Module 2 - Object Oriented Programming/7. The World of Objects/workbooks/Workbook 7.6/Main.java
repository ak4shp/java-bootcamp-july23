public class Main {
  
    public static void main(String[] args) {

        Person person = new Person("Rayan Slim", "Canadian", "11/11/1111", 5); 
        if (person.applyPassport()) {

        }
     }
     
}
